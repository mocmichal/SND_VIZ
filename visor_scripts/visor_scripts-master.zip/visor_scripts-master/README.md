# visor_scripts

scripts in ruby - for visor.live 

midi mapping config files in json
